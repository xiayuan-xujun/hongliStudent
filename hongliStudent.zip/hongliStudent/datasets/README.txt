1、Chinese_words ： 存放中文单词txt文件，默认一行一个单词或者短语
2、English_words: 存放英文单词txt文件，同上
3、student_class: 存放不同的班级名单
4、paper_test_words_frequency: 存放统计的paper_test，试卷的词频统计，有图片或者电子版
5、paper_test: 存放试卷的影像版或者电子版